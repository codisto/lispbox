#!/bin/sh
h-to-ffi.sh -m64 -D_NATIVE_OBJC_EXCEPTIONS -I/usr/include/GNUstep /usr/include/GNUstep/Cocoa/Cocoa.h
