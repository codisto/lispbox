#!/bin/bash
if [ "${0:0:2}" = "./" ]; then
    export LISPBOX_HOME=`pwd`
else
    export LISPBOX_HOME=`dirname $0`
fi
export SBCL_HOME=${LISPBOX_HOME}/sbcl-1.2.4/lib/sbcl
export EMACSDATA=${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/etc/
export EMACSDOC=${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/etc/
export EMACSLOADPATH=${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/site-lisp:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/site-lisp:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/leim:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/toolbar:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/textmodes:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/progmodes:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/play:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/obsolete:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/net:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/mail:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/language:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/international:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/gnus:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/eshell:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/emulation:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/emacs-lisp:\
${LISPBOX_HOME}/emacs-24.3/share/emacs/24.3/lisp/calendar


PATH=$PATH:${LISPBOX_HOME}/libexec/emacs/24.3/i686-pc-linux-gnu
exec ${LISPBOX_HOME}/emacs-24.3/bin/emacs --no-init-file --no-site-file --eval='(progn (load "lispbox") (slime))'
